
import { ConversationStartResponse, Activity, ActivitySet } from '../types';

const DIRECT_LINE_DOMAIN = 'https://directline.botframework.com/v3/directline';

/**
 * Exchanges a valid Power Platform / AAD Access Token for a Direct Line Token.
 * Matches logic from: copilotstudio-webclient/web/index.js
 */
export const exchangePowerPlatformToken = async (
  accessToken: string,
  environmentEndpoint: string,
  botSchemaName: string
): Promise<{ token: string; conversationId?: string }> => {
  
  // Clean endpoint: Ensure it starts with https and doesn't end with slash
  let baseUrl = environmentEndpoint.trim();
  if (baseUrl.endsWith('/')) baseUrl = baseUrl.slice(0, -1);
  if (!baseUrl.startsWith('http')) baseUrl = `https://${baseUrl}`;

  // Construct URL: {EnvUrl}/powervirtualagents/serviceagents/{BotId}/token?api-version=2022-03-01-preview
  // Note: The sample index.js constructs it exactly like this.
  const tokenUrl = `${baseUrl}/powervirtualagents/serviceagents/${botSchemaName}/token?api-version=2022-03-01-preview`;

  console.log(`[Auth] Exchanging user token at: ${tokenUrl}`);

  const response = await fetch(tokenUrl, {
    method: 'GET', 
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Token Exchange Failed (${response.status}) at ${tokenUrl}. Details: ${errText}`);
  }

  // Expecting JSON with { token: "...", conversationId: "..." }
  return response.json();
};

/**
 * Starts a new conversation with the Direct Line API.
 */
export const startConversation = async (token: string): Promise<ConversationStartResponse> => {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
  };

  const response = await fetch(`${DIRECT_LINE_DOMAIN}/conversations`, {
    method: 'POST',
    headers,
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to start conversation: ${response.status} ${response.statusText} - ${errorText}`);
  }

  return response.json();
};

/**
 * Sends an activity (message/attachment) to the bot.
 */
export const postActivity = async (
  conversationId: string,
  token: string,
  activity: Partial<Activity>
): Promise<{ id: string }> => {
  
  // Construct a compliant Direct Line activity.
  const payload: any = {
    type: 'message',
    from: {
      id: activity.from?.id,
      name: activity.from?.name || 'User',
      role: 'user' 
    },
    locale: navigator.language || 'en-US',
    timestamp: new Date().toISOString(),
    localTimestamp: new Date().toISOString(),
    channelData: {
      clientActivityId: Date.now().toString(),
      ...activity.channelData
    }
  };

  // STRICT TEXT HANDLING:
  // If text is provided, include it.
  // If an attachment is provided but no text, we MUST send text: "" 
  // so the bot's NLP pipeline processes it as an attachment message.
  if (typeof activity.text === 'string' && activity.text.length > 0) {
    payload.text = activity.text;
  } else if (activity.attachments && activity.attachments.length > 0) {
    payload.text = ""; // Required for Copilot Studio to recognize attachment-only messages
  }

  if (activity.attachments && activity.attachments.length > 0) {
    payload.attachments = activity.attachments;
  }

  const response = await fetch(`${DIRECT_LINE_DOMAIN}/conversations/${conversationId}/activities`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error(`Failed to send message: ${response.statusText}`);
  }

  return response.json();
};

/**
 * Polls for new activities from the bot.
 */
export const getActivities = async (
  conversationId: string,
  token: string,
  watermark?: string
): Promise<ActivitySet> => {
  const url = new URL(`${DIRECT_LINE_DOMAIN}/conversations/${conversationId}/activities`);
  if (watermark) {
    url.searchParams.append('watermark', watermark);
  }

  const response = await fetch(url.toString(), {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to get activities: ${response.statusText}`);
  }

  return response.json();
};

/**
 * Helper to convert a File object to a Base64 string suitable for Direct Line attachments.
 */
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result);
    };
    reader.onerror = (error) => reject(error);
  });
};
