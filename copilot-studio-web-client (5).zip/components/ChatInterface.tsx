import React, { useState, useEffect, useRef } from 'react';
import { Activity, BotConfig } from '../types';
import * as DirectLine from '../services/directLineService';
import MessageBubble from './MessageBubble';

interface ChatInterfaceProps {
  config: BotConfig;
  onDisconnect: () => void;
}

const POLLING_INTERVAL = 1000;

const ChatInterface: React.FC<ChatInterfaceProps> = ({ config, onDisconnect }) => {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [inputText, setInputText] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const watermarkRef = useRef<string | undefined>(undefined);
  const conversationIdRef = useRef<string | null>(config.conversationId || null);
  const tokenRef = useRef<string | null>(config.directLineToken);
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activities]);

  // Initial connection
  useEffect(() => {
    const initChat = async () => {
      try {
        if (!tokenRef.current) throw new Error("No token provided");

        // Start conversation if we don't have an ID yet
        if (!conversationIdRef.current) {
             const response = await DirectLine.startConversation(tokenRef.current);
             conversationIdRef.current = response.conversationId;
        }

      } catch (err: any) {
        console.error(err);
        setError(err.message || "Failed to start conversation.");
      }
    };

    initChat();
  }, [config]);

  // Polling
  useEffect(() => {
    const poll = async () => {
      if (!conversationIdRef.current || !tokenRef.current) return;

      try {
        const response = await DirectLine.getActivities(
          conversationIdRef.current,
          tokenRef.current,
          watermarkRef.current
        );

        if (response.watermark) {
          watermarkRef.current = response.watermark;
        }

        if (response.activities && response.activities.length > 0) {
          const newActivities = response.activities.filter(
            act => (act.type === 'message' || act.type === 'event') && act.id
          );
          
          if (newActivities.length > 0) {
              setActivities(prev => {
                  const existingIds = new Set(prev.map(a => a.id));
                  const uniqueNew = newActivities.filter(a => !existingIds.has(a.id));
                  return [...prev, ...uniqueNew];
              });
          }
        }
      } catch (err) {
        console.warn("Polling error:", err);
      }
    };

    const intervalId = setInterval(poll, POLLING_INTERVAL);
    return () => clearInterval(intervalId);
  }, []);

  const handleSendMessage = async () => {
    const textToSend = inputText.trim();
    if ((!textToSend && !selectedFile) || !conversationIdRef.current || !tokenRef.current) return;

    setIsSending(true);
    
    try {
      const activity: Partial<Activity> = {
        type: 'message',
        from: { id: config.userId, name: config.userName },
        // IMPORTANT: If file is selected, sending null text allows the bot to focus on attachment.
        text: selectedFile ? undefined : textToSend, 
      };

      if (selectedFile) {
        const base64Data = await DirectLine.fileToBase64(selectedFile);
        activity.attachments = [
          {
            contentType: selectedFile.type || 'application/octet-stream',
            contentUrl: base64Data,
            name: selectedFile.name,
          },
        ];
      }

      // Optimistic UI update
      const tempId = `temp-${Date.now()}`;
      setActivities(prev => [...prev, { ...activity, id: tempId, timestamp: new Date().toISOString() } as Activity]);
      
      // Clear inputs immediately
      setInputText('');
      setSelectedFile(null);
      if(fileInputRef.current) fileInputRef.current.value = '';

      await DirectLine.postActivity(conversationIdRef.current, tokenRef.current, activity);
      
    } catch (err: any) {
      console.error(err);
      setError("Failed to send message: " + err.message);
      setActivities(prev => prev.filter(a => !a.id?.startsWith('temp-')));
    } finally {
      setIsSending(false);
    }
  };

  const handleSuggestedAction = (value: string) => {
    sendMessageDirect(value);
  };

  const sendMessageDirect = async (text: string) => {
      if (!conversationIdRef.current || !tokenRef.current) return;
      setIsSending(true);
      try {
           const activity: Partial<Activity> = {
            type: 'message',
            from: { id: config.userId, name: config.userName },
            text: text,
          };
          
          setActivities(prev => [...prev, { ...activity, id: `temp-${Date.now()}`, timestamp: new Date().toISOString() } as Activity]);
          await DirectLine.postActivity(conversationIdRef.current, tokenRef.current, activity);
      } catch(err) {
          console.error(err);
      } finally {
          setIsSending(false);
      }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 4 * 1024 * 1024) {
          alert("File is too large. Copilot Studio typically accepts files under 4MB.");
          e.target.value = '';
          return;
      }
      setSelectedFile(file);
    }
  };

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6 text-center">
        <div className="bg-red-900/50 border border-red-500 text-red-100 p-6 rounded-xl max-w-md">
          <h3 className="text-xl font-bold mb-2">Connection Error</h3>
          <p className="mb-4 break-words text-sm">{error}</p>
          <button 
            onClick={onDisconnect}
            className="px-4 py-2 bg-red-600 hover:bg-red-500 rounded-lg transition"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen max-w-5xl mx-auto bg-gray-900 shadow-2xl overflow-hidden border-x border-gray-800">
      {/* Header */}
      <div className="bg-gray-800 p-4 border-b border-gray-700 flex justify-between items-center z-10 shadow-sm">
        <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center font-bold text-white shadow-lg ring-2 ring-gray-700">
                AI
            </div>
            <div>
                <h1 className="font-bold text-white text-lg leading-tight">Copilot Agent</h1>
                <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                    <span className="text-xs text-green-400 font-medium">Online</span>
                </div>
            </div>
        </div>
        <button 
            onClick={onDisconnect}
            className="text-gray-400 hover:text-white transition text-sm flex items-center gap-1 px-3 py-1.5 rounded-lg hover:bg-gray-700"
        >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            End
        </button>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-gray-900 space-y-4">
        {activities.length === 0 ? (
           <div className="h-full flex flex-col items-center justify-center text-gray-500 opacity-60">
               <svg className="w-20 h-20 mb-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
               <p className="text-lg">Waiting for agent...</p>
           </div>
        ) : (
          activities.map((activity, index) => (
            <MessageBubble 
                key={activity.id || index} 
                activity={activity} 
                isOwn={activity.from.id === config.userId} 
                onSuggestedActionClick={handleSuggestedAction}
            />
          ))
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-gray-800 border-t border-gray-700">
        
        {/* Selected File Preview */}
        {selectedFile && (
            <div className="flex items-center gap-3 mb-3 p-2 bg-gray-700/50 rounded-lg border border-gray-600 w-fit animate-fade-in-up">
                <div className="p-2 bg-gray-600 rounded">
                    <svg className="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                </div>
                <div className="flex flex-col">
                    <span className="text-sm text-gray-200 font-medium truncate max-w-[200px]">{selectedFile.name}</span>
                    <span className="text-xs text-gray-400">{(selectedFile.size / 1024).toFixed(1)} KB</span>
                </div>
                <button 
                    onClick={() => {
                        setSelectedFile(null);
                        if(fileInputRef.current) fileInputRef.current.value = '';
                    }}
                    className="ml-2 p-1 hover:bg-gray-600 rounded-full text-gray-400 hover:text-white"
                >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </div>
        )}

        <div className="flex gap-2">
            <button
                onClick={() => fileInputRef.current?.click()}
                className="p-3 text-gray-400 hover:text-white hover:bg-gray-700 rounded-xl transition-colors shrink-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                title="Attach file"
            >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                </svg>
            </button>
            <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileSelect} 
                className="hidden" 
            />
            
            <div className="flex-1 relative">
                <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={handleKeyDown}
                    disabled={!!selectedFile}
                    placeholder={selectedFile ? "Send file..." : "Type message or paste link..."}
                    className={`w-full bg-gray-700 text-white placeholder-gray-400 border border-gray-600 rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-12 transition-all ${selectedFile ? 'opacity-50 cursor-not-allowed' : ''}`}
                />
            </div>

            <button
                onClick={handleSendMessage}
                disabled={isSending || (!inputText.trim() && !selectedFile)}
                className={`p-3 rounded-xl flex items-center justify-center transition-all duration-200 ${
                    isSending || (!inputText.trim() && !selectedFile)
                    ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                    : 'bg-blue-600 text-white hover:bg-blue-500 shadow-lg shadow-blue-500/20'
                }`}
            >
               {isSending ? (
                   <svg className="w-6 h-6 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
               ) : (
                   <svg className="w-6 h-6 transform rotate-90" fill="currentColor" viewBox="0 0 20 20"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>
               )}
            </button>
        </div>
        <p className="text-xs text-gray-500 mt-2 text-center">
            If you get a validation code after signing in, paste it here.
        </p>
      </div>
    </div>
  );
};

export default ChatInterface;