export interface Attachment {
  contentType: string;
  contentUrl?: string;
  content?: any;
  name?: string;
  thumbnailUrl?: string;
}

export interface HeroCardContent {
  title?: string;
  subtitle?: string;
  text?: string;
  buttons?: Array<{
    type: string;
    title: string;
    value: string;
  }>;
  images?: Array<{
    url: string;
    alt?: string;
  }>;
}

export interface OAuthCardContent {
  text?: string;
  connectionName: string;
  buttons: Array<{
    type: string;
    title: string;
    value: string;
  }>;
}

export interface ThumbnailCardContent {
  title?: string;
  subtitle?: string;
  text?: string;
  images?: Array<{
    url: string;
    alt?: string;
  }>;
  buttons?: Array<{
    type: string;
    title: string;
    value: string;
  }>;
}

export interface Activity {
  type: 'message' | 'typing' | 'event' | 'conversationUpdate' | string;
  id?: string;
  timestamp?: string;
  localTimestamp?: string;
  locale?: string;
  from: {
    id: string;
    name?: string;
    role?: 'user' | 'bot' | 'channel';
  };
  conversation?: {
    id: string;
  };
  text?: string;
  attachments?: Attachment[];
  suggestedActions?: {
    actions: Array<{
      type: string;
      title: string;
      value: string;
    }>;
  };
  channelData?: any;
}

export interface ConversationStartResponse {
  conversationId: string;
  token: string;
  expires_in?: number;
  streamUrl?: string;
  referenceGrammarId?: string;
}

export interface ActivitySet {
  activities: Activity[];
  watermark?: string;
}

export interface BotConfig {
  tokenEndpoint?: string;
  secretOrToken?: string;
  userId: string;
  userName: string;
}