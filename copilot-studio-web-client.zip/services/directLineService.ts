import { ConversationStartResponse, Activity, ActivitySet } from '../types';

const DIRECT_LINE_DOMAIN = 'https://directline.botframework.com/v3/directline';

/**
 * Fetches a Direct Line token from a Power Platform / Copilot Studio Token Endpoint.
 */
export const getTokenFromEndpoint = async (endpointUrl: string): Promise<{ token: string; conversationId?: string }> => {
  // First try GET (standard)
  try {
    const response = await fetch(endpointUrl);
    if (!response.ok) {
        throw new Error(`GET failed: ${response.status}`);
    }
    return response.json();
  } catch (e) {
    // Fallback to POST (some Dataverse endpoints prefer this)
    const response = await fetch(endpointUrl, { method: 'POST' });
    if (!response.ok) {
        throw new Error(`Failed to get token from endpoint: ${response.status} ${response.statusText}`);
    }
    return response.json();
  }
};

/**
 * Starts a new conversation with the Direct Line API.
 */
export const startConversation = async (token: string): Promise<ConversationStartResponse> => {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
  };

  const response = await fetch(`${DIRECT_LINE_DOMAIN}/conversations`, {
    method: 'POST',
    headers,
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to start conversation: ${response.status} ${response.statusText} - ${errorText}`);
  }

  return response.json();
};

/**
 * Sends an activity (message/attachment) to the bot.
 */
export const postActivity = async (
  conversationId: string,
  token: string,
  activity: Partial<Activity>
): Promise<{ id: string }> => {
  
  // Construct a compliant Direct Line activity
  // M365 Agents / Copilot Studio are strict about locale and text/attachment separation
  const payload = {
    type: 'message',
    from: {
      id: activity.from?.id,
      name: activity.from?.name || 'User',
      role: 'user' 
    },
    locale: navigator.language || 'en-US',
    
    // CRITICAL for Copilot Studio:
    // 1. If sending file, 'text' should be explicitly NULL (not undefined), or empty string? 
    //    Tests show 'null' works best to signal "this is an attachment message".
    // 2. If sending text, send it as string.
    text: activity.text || null, 
    
    attachments: activity.attachments || [],
    timestamp: new Date().toISOString(),
    localTimestamp: new Date().toISOString(),
    
    // inputHint helps the bot understand the user is done speaking/uploading
    inputHint: 'expectingInput', 
    
    channelData: {
      clientActivityId: Date.now().toString(),
      ...activity.channelData
    }
  };

  const response = await fetch(`${DIRECT_LINE_DOMAIN}/conversations/${conversationId}/activities`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error(`Failed to send message: ${response.statusText}`);
  }

  return response.json();
};

/**
 * Polls for new activities from the bot.
 */
export const getActivities = async (
  conversationId: string,
  token: string,
  watermark?: string
): Promise<ActivitySet> => {
  const url = new URL(`${DIRECT_LINE_DOMAIN}/conversations/${conversationId}/activities`);
  if (watermark) {
    url.searchParams.append('watermark', watermark);
  }

  const response = await fetch(url.toString(), {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to get activities: ${response.statusText}`);
  }

  return response.json();
};

/**
 * Helper to convert a File object to a Base64 string suitable for Direct Line attachments.
 */
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result);
    };
    reader.onerror = (error) => reject(error);
  });
};