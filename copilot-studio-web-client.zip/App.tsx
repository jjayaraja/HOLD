import React, { useState } from 'react';
import ChatInterface from './components/ChatInterface';
import { BotConfig } from './types';

const App: React.FC = () => {
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [connectionString, setConnectionString] = useState('');

  const handleStart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!connectionString.trim()) return;

    setConfig({
      tokenEndpoint: connectionString.trim(),
      userId: `user-${Math.floor(Math.random() * 1000000)}`, // Random session ID
      userName: 'User',
    });
  };

  if (config) {
    return <ChatInterface config={config} onDisconnect={() => setConfig(null)} />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-950 p-4 font-sans">
      <div className="bg-gray-900 border border-gray-800 p-8 rounded-2xl shadow-2xl max-w-lg w-full relative overflow-hidden">
        {/* Decorative background element */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"></div>
        
        <div className="text-center mb-8 relative z-10">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl mx-auto flex items-center justify-center mb-6 shadow-lg shadow-blue-900/30 ring-4 ring-gray-800">
             <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Copilot Client</h1>
          <p className="text-gray-400 text-sm leading-relaxed max-w-xs mx-auto">
            Connect to your M365 Copilot Studio Agent.
          </p>
        </div>

        <form onSubmit={handleStart} className="space-y-6 relative z-10">
          
            <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                Connection String / Endpoint
                </label>
                <input
                type="url"
                value={connectionString}
                onChange={(e) => setConnectionString(e.target.value)}
                placeholder="https://.../copilotstudio/.../bots/..."
                className="w-full bg-gray-800 text-white border border-gray-700 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all placeholder-gray-600 text-sm"
                required
                />
                <p className="text-xs text-gray-500 mt-2">
                Paste the full URL from the Agent SDK or Copilot Studio Channel settings.
                </p>
            </div>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3.5 px-6 rounded-xl transition duration-200 transform hover:scale-[1.01] shadow-lg shadow-blue-600/25"
          >
            Connect
          </button>
        </form>

      </div>
    </div>
  );
};

export default App;