import React from 'react';
import { Activity, Attachment, HeroCardContent, OAuthCardContent, ThumbnailCardContent } from '../types';

interface MessageBubbleProps {
  activity: Activity;
  isOwn: boolean;
  onSuggestedActionClick?: (value: string) => void;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ activity, isOwn, onSuggestedActionClick }) => {
  // Render simple text
  const renderText = () => {
    if (!activity.text) return null;
    return <p className="whitespace-pre-wrap break-words">{activity.text}</p>;
  };

  // Render Attachments (Images, Cards, Files)
  const renderAttachments = () => {
    if (!activity.attachments || activity.attachments.length === 0) return null;

    return (
      <div className="flex flex-col gap-2 mt-2 w-full">
        {activity.attachments.map((att: Attachment, index: number) => {
          // Handle Images
          if (att.contentType.startsWith('image/')) {
            return (
              <img
                key={index}
                src={att.contentUrl}
                alt={att.name || 'Attachment'}
                className="max-w-full rounded-lg border border-gray-600 max-h-64 object-cover"
              />
            );
          }

          // Handle OAuth Cards (Microsoft Authentication)
          if (att.contentType === 'application/vnd.microsoft.card.oauth') {
             const content = att.content as OAuthCardContent;
             return (
               <div key={index} className="bg-gray-800 border border-yellow-600/50 rounded-lg p-4 min-w-[200px]">
                 <h4 className="font-bold text-lg mb-2 text-yellow-500">Authentication Required</h4>
                 <p className="text-sm text-gray-300 mb-3">{content.text || "Please sign in to continue."}</p>
                 {content.buttons && content.buttons.map((btn, i) => (
                   <button 
                     key={i}
                     onClick={() => {
                        window.open(btn.value, '_blank', 'width=800,height=600');
                     }}
                     className="w-full bg-yellow-600 hover:bg-yellow-500 text-white font-medium py-2 px-4 rounded transition-colors"
                   >
                     {btn.title}
                   </button>
                 ))}
                 <p className="text-xs text-gray-500 mt-2">
                   If you receive a validation code, paste it into the chat.
                 </p>
               </div>
             );
          }

          // Handle Hero Cards
          if (att.contentType === 'application/vnd.microsoft.card.hero') {
            const content = att.content as HeroCardContent;
            return (
              <div key={index} className="bg-gray-800 border border-gray-600 rounded-lg p-3 min-w-[200px]">
                {content.title && <h4 className="font-bold text-lg mb-1">{content.title}</h4>}
                {content.subtitle && <h5 className="font-semibold text-gray-400 mb-2">{content.subtitle}</h5>}
                {content.text && <p className="text-sm mb-3">{content.text}</p>}
                {content.images && content.images.map((img, i) => (
                   <img key={i} src={img.url} alt={img.alt} className="rounded mb-2 w-full object-cover" />
                ))}
                {content.buttons && (
                  <div className="flex flex-col gap-1">
                    {content.buttons.map((btn, btnIdx) => (
                      <button
                        key={btnIdx}
                        onClick={() => {
                            if (btn.type === 'openUrl') {
                                window.open(btn.value, '_blank');
                            } else {
                                onSuggestedActionClick && onSuggestedActionClick(btn.value);
                            }
                        }}
                        className="bg-blue-600 hover:bg-blue-700 text-white text-sm py-2 px-3 rounded transition"
                      >
                        {btn.title}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          }

          // Handle Thumbnail Cards
          if (att.contentType === 'application/vnd.microsoft.card.thumbnail') {
             const content = att.content as ThumbnailCardContent;
             return (
               <div key={index} className="bg-gray-800 border border-gray-600 rounded-lg p-3 flex gap-4">
                  {content.images && content.images.length > 0 && (
                     <img src={content.images[0].url} alt={content.images[0].alt} className="w-16 h-16 object-cover rounded" />
                  )}
                  <div className="flex-1">
                     {content.title && <h4 className="font-bold text-base">{content.title}</h4>}
                     {content.subtitle && <p className="text-xs text-gray-400">{content.subtitle}</p>}
                     {content.text && <p className="text-sm mt-1">{content.text}</p>}
                     {content.buttons && (
                        <div className="flex gap-2 mt-2">
                           {content.buttons.map((btn, i) => (
                              <button key={i} onClick={() => onSuggestedActionClick && onSuggestedActionClick(btn.value)} className="text-blue-400 text-xs hover:underline">
                                 {btn.title}
                              </button>
                           ))}
                        </div>
                     )}
                  </div>
               </div>
             )
          }

          // Render uploaded file generic view
          return (
             <div key={index} className="flex items-center gap-2 bg-gray-800 p-2 rounded border border-gray-600 max-w-xs">
                <svg className="w-5 h-5 text-gray-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <div className="overflow-hidden">
                    <span className="text-sm text-gray-300 truncate block">{att.name || 'Unknown File'}</span>
                </div>
             </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className={`flex w-full ${isOwn ? 'justify-end' : 'justify-start'} mb-4 animate-fade-in`}>
      <div className={`max-w-[85%] md:max-w-[75%] lg:max-w-[65%] flex flex-col ${isOwn ? 'items-end' : 'items-start'}`}>
        <div
          className={`px-4 py-3 rounded-2xl shadow-md ${
            isOwn
              ? 'bg-blue-600 text-white rounded-br-none'
              : 'bg-gray-700 text-gray-100 rounded-bl-none w-full'
          }`}
        >
          {renderText()}
          {renderAttachments()}
        </div>
        
        {/* Suggested Actions (Quick Replies) */}
        {!isOwn && activity.suggestedActions && activity.suggestedActions.actions.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {activity.suggestedActions.actions.map((action, idx) => (
              <button
                key={idx}
                onClick={() => onSuggestedActionClick && onSuggestedActionClick(action.value)}
                className="bg-gray-800 hover:bg-gray-600 border border-blue-500/30 text-blue-400 text-sm py-1.5 px-4 rounded-full transition-colors duration-200"
              >
                {action.title}
              </button>
            ))}
          </div>
        )}
        
        <span className="text-xs text-gray-500 mt-1 mx-1">
          {isOwn ? 'You' : 'Copilot'} • {new Date(activity.timestamp || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </div>
  );
};

export default MessageBubble;