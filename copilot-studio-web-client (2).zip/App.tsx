
import React, { useState, useEffect } from 'react';
import ChatInterface from './components/ChatInterface';
import { BotConfig, AppSettings } from './types';
import * as DirectLine from './services/directLineService';

const DEFAULT_SETTINGS: AppSettings = {
  tenantId: '',
  clientId: '',
  clientSecret: '',
  endpointUrl: '',
};

const App: React.FC = () => {
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  
  // Settings State
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load settings on mount
  useEffect(() => {
    const saved = localStorage.getItem('copilot-client-settings');
    if (saved) {
      try {
        setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(saved) });
      } catch (e) {
        console.error("Failed to parse settings", e);
      }
    } else {
      setShowSettings(true);
    }
  }, []);

  const saveSettings = () => {
    localStorage.setItem('copilot-client-settings', JSON.stringify(settings));
    setShowSettings(false);
    setError(null);
  };

  const handleConnect = async () => {
    setError(null);
    setIsLoading(true);

    try {
      const { tenantId, clientId, clientSecret, endpointUrl } = settings;

      if (!tenantId || !clientId || !clientSecret || !endpointUrl) {
        throw new Error("Missing required settings. Please click the Gear icon to configure.");
      }

      // 1. Authenticate with Service Principal to get Direct Line Token
      // NOTE: This performs a direct call to AAD.
      const authResult = await DirectLine.getDirectLineTokenWithServicePrincipal(
        tenantId,
        clientId,
        clientSecret,
        endpointUrl
      );

      if (!authResult.token) {
        throw new Error("Did not receive a token from the Agent Endpoint.");
      }

      // 2. Set Config
      setConfig({
        directLineToken: authResult.token,
        conversationId: authResult.conversationId,
        userId: `user-${Math.floor(Math.random() * 1000000)}`,
        userName: 'User',
      });

    } catch (err: any) {
      console.error(err);
      let errMsg = err.message || "Connection failed.";
      
      // Heuristic check for CORS failure on AAD endpoint
      if (errMsg.toLowerCase().includes('failed to fetch')) {
        errMsg += " (CORS Error: Browsers block direct Client Credential requests. You may need to disable web security or use a proxy.)";
      }
      
      setError(errMsg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDisconnect = () => {
    setConfig(null);
    setError(null);
  };

  if (config) {
    return (
      <ChatInterface 
        config={config} 
        onDisconnect={handleDisconnect} 
      />
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-950 p-4 font-sans relative">
      
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-900/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-900/20 rounded-full blur-3xl"></div>
      </div>

      <div className="bg-gray-900 border border-gray-800 p-8 rounded-2xl shadow-2xl max-w-md w-full relative z-10">
        
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-tr from-blue-600 to-indigo-600 rounded-2xl mx-auto flex items-center justify-center mb-6 shadow-lg shadow-blue-500/20 ring-4 ring-gray-800">
             <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Copilot Web Client</h1>
          <p className="text-gray-400">Connect using M365 Agent SDK Protocol (C# Logic).</p>
        </div>

        {error && (
          <div className="mb-6 bg-red-900/20 border border-red-500/30 text-red-200 p-4 rounded-xl text-sm">
            <div className="flex gap-2">
               <svg className="w-5 h-5 shrink-0 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
               <span className="break-words">{error}</span>
            </div>
          </div>
        )}

        <button
            onClick={handleConnect}
            disabled={isLoading}
            className={`w-full font-bold py-4 px-6 rounded-xl transition-all duration-200 shadow-lg flex justify-center items-center text-lg ${
                isLoading 
                ? 'bg-gray-800 text-gray-400 cursor-not-allowed' 
                : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-blue-900/20'
            }`}
        >
          {isLoading ? (
             <>
               <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                 <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                 <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
               </svg>
               Connecting...
             </>
          ) : (
            'Connect'
          )}
        </button>

        <div className="mt-6 flex justify-center">
          <button 
            onClick={() => setShowSettings(true)}
            className="text-gray-500 hover:text-white transition flex items-center gap-2 text-sm"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
            Configure Credentials
          </button>
        </div>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 w-full max-w-lg shadow-2xl transform transition-all scale-100">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" /></svg>
              Agent Configuration
            </h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Tenant ID</label>
                <input 
                  type="text" 
                  value={settings.tenantId} 
                  onChange={(e) => setSettings({...settings, tenantId: e.target.value})}
                  placeholder="e.g. 72f988bf-..."
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Client ID</label>
                  <input 
                    type="text" 
                    value={settings.clientId} 
                    onChange={(e) => setSettings({...settings, clientId: e.target.value})}
                    placeholder="Application ID"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Client Secret</label>
                  <input 
                    type="password" 
                    value={settings.clientSecret} 
                    onChange={(e) => setSettings({...settings, clientSecret: e.target.value})}
                    placeholder="Value (not ID)"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Endpoint URL</label>
                <input 
                  type="text" 
                  value={settings.endpointUrl} 
                  onChange={(e) => setSettings({...settings, endpointUrl: e.target.value})}
                  placeholder="https://<org>.<region>.environment.api.powerplatform.com/..."
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
                <p className="text-xs text-gray-500 mt-1">Found in Copilot Studio &gt; Settings &gt; Developers</p>
              </div>

              <div className="bg-blue-900/20 border border-blue-800 rounded-lg p-3 mt-4">
                  <p className="text-xs text-blue-200">
                      <strong>Note:</strong> This uses Client Credentials Flow. Direct calls to Azure AD from a browser will likely fail with CORS unless you disable browser security or use a local environment.
                  </p>
              </div>

            </div>

            <div className="mt-8 flex justify-end gap-3">
              <button 
                onClick={() => setShowSettings(false)}
                className="px-4 py-2 text-gray-400 hover:text-white transition"
              >
                Cancel
              </button>
              <button 
                onClick={saveSettings}
                className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium transition shadow-lg shadow-blue-500/20"
              >
                Save Configuration
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
