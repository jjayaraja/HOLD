
import { ConversationStartResponse, Activity, ActivitySet } from '../types';

const DIRECT_LINE_DOMAIN = 'https://directline.botframework.com/v3/directline';

/**
 * Exchange Client Credentials for a Direct Line Token via Power Platform API.
 * This mirrors the logic in the C# Console Sample.
 * 
 * NOTE: This will fail in a standard browser due to CORS on login.microsoftonline.com
 * unless security is disabled or an extension is used.
 */
export const getDirectLineTokenWithServicePrincipal = async (
  tenantId: string,
  clientId: string,
  clientSecret: string,
  endpointUrl: string
): Promise<{ token: string; conversationId?: string }> => {
  
  // 1. Get AAD Token for Power Platform
  // Target: https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token
  // Scope: https://api.powerplatform.com/.default
  
  const aadTokenUrl = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
  
  const body = new URLSearchParams();
  body.append('grant_type', 'client_credentials');
  body.append('client_id', clientId);
  body.append('client_secret', clientSecret);
  body.append('scope', 'https://api.powerplatform.com/.default');

  console.log(`[Auth] Requesting AAD token from: ${aadTokenUrl}`);

  const aadResponse = await fetch(aadTokenUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString()
  });

  if (!aadResponse.ok) {
    const errText = await aadResponse.text();
    throw new Error(`AAD Auth Failed (${aadResponse.status}): ${errText}`);
  }

  const aadData = await aadResponse.json();
  const ppToken = aadData.access_token;

  if (!ppToken) {
    throw new Error("Received empty access token from AAD.");
  }

  // 2. Exchange AAD Token for Direct Line Token at the Bot Endpoint
  // Pattern: {EndpointUrl}/directline/token?api-version=2022-03-01-preview
  
  let cleanEndpoint = endpointUrl.trim();
  // Fix common copy-paste typos from Power Platform UI
  if (cleanEndpoint.startsWith('httpus://')) cleanEndpoint = cleanEndpoint.replace('httpus://', 'https://');
  if (!cleanEndpoint.startsWith('http')) cleanEndpoint = `https://${cleanEndpoint}`;
  if (cleanEndpoint.endsWith('/')) cleanEndpoint = cleanEndpoint.slice(0, -1);

  // If the user pasted the base URL, append the token path.
  // If they pasted the full token URL, use it as is.
  let tokenEndpoint = cleanEndpoint;
  if (!tokenEndpoint.includes('/directline/token')) {
    tokenEndpoint = `${cleanEndpoint}/directline/token?api-version=2022-03-01-preview`;
  } else if (!tokenEndpoint.includes('api-version=')) {
      tokenEndpoint = `${tokenEndpoint}${tokenEndpoint.includes('?') ? '&' : '?'}api-version=2022-03-01-preview`;
  }

  console.log(`[Auth] Exchanging token at endpoint: ${tokenEndpoint}`);

  // C# Sample uses GET usually, but some endpoints support POST. We try GET first.
  const ppResponse = await fetch(tokenEndpoint, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${ppToken}`,
      'Content-Type': 'application/json'
    }
  });

  if (!ppResponse.ok) {
    // Fallback to POST if GET fails (some older endpoints)
    console.log('[Auth] GET failed, trying POST...');
    const ppResponsePost = await fetch(tokenEndpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${ppToken}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!ppResponsePost.ok) {
       const errText = await ppResponsePost.text();
       throw new Error(`Copilot Token Fetch Failed (${ppResponsePost.status}): ${errText}`);
    }
    return ppResponsePost.json();
  }

  return ppResponse.json();
};

/**
 * Starts a new conversation with the Direct Line API.
 */
export const startConversation = async (token: string): Promise<ConversationStartResponse> => {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
  };

  const response = await fetch(`${DIRECT_LINE_DOMAIN}/conversations`, {
    method: 'POST',
    headers,
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to start conversation: ${response.status} ${response.statusText} - ${errorText}`);
  }

  return response.json();
};

/**
 * Sends an activity (message/attachment) to the bot.
 */
export const postActivity = async (
  conversationId: string,
  token: string,
  activity: Partial<Activity>
): Promise<{ id: string }> => {
  
  // Construct a compliant Direct Line activity.
  // We avoid adding keys that are null/undefined to keep the payload clean.
  
  const payload: any = {
    type: 'message',
    from: {
      id: activity.from?.id,
      name: activity.from?.name || 'User',
      role: 'user' 
    },
    locale: navigator.language || 'en-US',
    timestamp: new Date().toISOString(),
    localTimestamp: new Date().toISOString(),
    channelData: {
      clientActivityId: Date.now().toString(),
      ...activity.channelData
    }
  };

  // Only attach text if it actually exists. 
  // Copilot Studio can get confused if 'text' is sent as null alongside attachments.
  if (activity.text) {
    payload.text = activity.text;
  }

  // Only attach attachments array if it has items
  if (activity.attachments && activity.attachments.length > 0) {
    payload.attachments = activity.attachments;
  }

  // NOTE: We removed 'inputHint' from the user payload. 
  // Sending 'expectingInput' from the user side can confuse the bot's dialog state 
  // (causing it to ignore the current message content).

  const response = await fetch(`${DIRECT_LINE_DOMAIN}/conversations/${conversationId}/activities`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error(`Failed to send message: ${response.statusText}`);
  }

  return response.json();
};

/**
 * Polls for new activities from the bot.
 */
export const getActivities = async (
  conversationId: string,
  token: string,
  watermark?: string
): Promise<ActivitySet> => {
  const url = new URL(`${DIRECT_LINE_DOMAIN}/conversations/${conversationId}/activities`);
  if (watermark) {
    url.searchParams.append('watermark', watermark);
  }

  const response = await fetch(url.toString(), {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to get activities: ${response.statusText}`);
  }

  return response.json();
};

/**
 * Helper to convert a File object to a Base64 string suitable for Direct Line attachments.
 */
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result);
    };
    reader.onerror = (error) => reject(error);
  });
};
