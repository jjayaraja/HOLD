
import React, { useState, useEffect } from 'react';
import ChatInterface from './components/ChatInterface';
import { BotConfig, AppSettings } from './types';
import * as DirectLine from './services/directLineService';
import { PublicClientApplication, Configuration, AuthenticationResult } from '@azure/msal-browser';

const DEFAULT_SETTINGS: AppSettings = {
  tenantId: '',
  clientId: '', // App ID
  environmentEndpoint: '', // e.g. https://org.api.powerplatform.com
  botSchemaName: '', // e.g. cr45f_agentName
};

const App: React.FC = () => {
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load settings on mount
  useEffect(() => {
    const saved = localStorage.getItem('copilot-client-settings-v2');
    if (saved) {
      try {
        setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(saved) });
      } catch (e) {
        console.error("Failed to parse settings", e);
      }
    } else {
      setShowSettings(true);
    }
  }, []);

  const saveSettings = () => {
    localStorage.setItem('copilot-client-settings-v2', JSON.stringify(settings));
    setShowSettings(false);
    setError(null);
  };

  const handleMicrosoftLogin = async () => {
    setError(null);
    setIsLoading(true);

    try {
        const { clientId, tenantId, environmentEndpoint, botSchemaName } = settings;

        if (!clientId || !tenantId || !environmentEndpoint || !botSchemaName) {
            setShowSettings(true);
            setIsLoading(false);
            return;
        }

        // 1. Initialize MSAL
        const msalConfig: Configuration = {
            auth: {
                clientId: clientId,
                authority: `https://login.microsoftonline.com/${tenantId}`,
                redirectUri: window.location.origin, // Must be registered in Azure AD
            },
            cache: {
                cacheLocation: "sessionStorage", 
                storeAuthStateInCookie: false,
            }
        };

        const msalInstance = new PublicClientApplication(msalConfig);
        await msalInstance.initialize();

        // 2. Login via Popup
        // Scope must be for Power Platform API
        const loginRequest = {
            scopes: ["https://api.powerplatform.com/Bot.Read"], 
        };

        let authResult: AuthenticationResult;
        try {
            authResult = await msalInstance.loginPopup(loginRequest);
        } catch (loginErr) {
            // Handle popup blocked or closed
            console.error(loginErr);
            throw new Error("Login failed or was closed. Please try again.");
        }

        console.log("Logged in:", authResult.account?.username);

        // 3. Exchange Power Platform Token for Direct Line Token
        const dlData = await DirectLine.exchangePowerPlatformToken(
            authResult.accessToken,
            environmentEndpoint,
            botSchemaName
        );

        if (!dlData.token) {
            throw new Error("Failed to retrieve Direct Line Token from agent endpoint.");
        }

        // 4. Start Chat
        setConfig({
            directLineToken: dlData.token,
            conversationId: dlData.conversationId,
            userId: authResult.account?.localAccountId || 'user',
            userName: authResult.account?.name || 'User',
        });

    } catch (err: any) {
        console.error("Connection Error:", err);
        setError(err.message || "An unexpected error occurred.");
    } finally {
        setIsLoading(false);
    }
  };

  const handleDisconnect = () => {
    setConfig(null);
    setError(null);
  };

  if (config) {
    return (
      <ChatInterface 
        config={config} 
        onDisconnect={handleDisconnect} 
      />
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-950 p-4 font-sans relative">
      
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-900/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-900/20 rounded-full blur-3xl"></div>
      </div>

      <div className="bg-gray-900 border border-gray-800 p-8 rounded-2xl shadow-2xl max-w-md w-full relative z-10">
        
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-tr from-blue-600 to-indigo-600 rounded-2xl mx-auto flex items-center justify-center mb-6 shadow-lg shadow-blue-500/20 ring-4 ring-gray-800">
             <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Copilot Login</h1>
          <p className="text-gray-400">Sign in with Microsoft to access your Agent.</p>
        </div>

        {error && (
          <div className="mb-6 bg-red-900/20 border border-red-500/30 text-red-200 p-4 rounded-xl text-sm flex gap-2">
               <svg className="w-5 h-5 shrink-0 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
               <span className="break-words font-semibold">{error}</span>
          </div>
        )}

        <button
            onClick={handleMicrosoftLogin}
            disabled={isLoading}
            className={`w-full font-bold py-4 px-6 rounded-xl transition-all duration-200 shadow-lg flex justify-center items-center text-lg gap-3 ${
                isLoading 
                ? 'bg-gray-800 text-gray-400 cursor-not-allowed' 
                : 'bg-white text-gray-900 hover:bg-gray-100 shadow-white/10'
            }`}
        >
          {isLoading ? (
             <>
               <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-gray-900" fill="none" viewBox="0 0 24 24">
                 <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                 <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
               </svg>
               Signing In...
             </>
          ) : (
             <>
                <svg className="w-5 h-5" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill="#F25022" d="M1 1H10V10H1z"/><path fill="#7FBA00" d="M12 1H21V10H12z"/><path fill="#00A4EF" d="M1 12H10V21H1z"/><path fill="#FFB900" d="M12 12H21V21H12z"/></svg>
                Sign In with Microsoft
             </>
          )}
        </button>

        <div className="mt-6 flex justify-center">
          <button 
            onClick={() => setShowSettings(true)}
            className="text-gray-500 hover:text-white transition flex items-center gap-2 text-sm"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
            Configuration
          </button>
        </div>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 w-full max-w-lg shadow-2xl transform transition-all scale-100 max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" /></svg>
              Authentication Configuration
            </h2>
            
            <p className="text-sm text-gray-400 mb-6">
                Enter the details from your Copilot Studio Agent & Azure App Registration.
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Tenant ID</label>
                <input 
                  type="text" 
                  value={settings.tenantId} 
                  onChange={(e) => setSettings({...settings, tenantId: e.target.value})}
                  placeholder="e.g. 72f988bf-..."
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Client ID (App ID)</label>
                  <input 
                    type="text" 
                    value={settings.clientId} 
                    onChange={(e) => setSettings({...settings, clientId: e.target.value})}
                    placeholder="Application ID from Azure AD"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                  <p className="text-[10px] text-gray-500 mt-1">Ensure "http://localhost:..." is added to Redirect URIs in Azure.</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Environment Endpoint</label>
                <input 
                  type="text" 
                  value={settings.environmentEndpoint} 
                  onChange={(e) => setSettings({...settings, environmentEndpoint: e.target.value})}
                  placeholder="https://<org>.<region>.environment.api.powerplatform.com"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Agent Schema Name (Bot ID)</label>
                <input 
                  type="text" 
                  value={settings.botSchemaName} 
                  onChange={(e) => setSettings({...settings, botSchemaName: e.target.value})}
                  placeholder="e.g. cr45f_copilotName"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

            </div>

            <div className="mt-8 flex justify-end gap-3">
              <button 
                onClick={() => setShowSettings(false)}
                className="px-4 py-2 text-gray-400 hover:text-white transition"
              >
                Close
              </button>
              <button 
                onClick={saveSettings}
                className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium transition shadow-lg shadow-blue-500/20"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
