import React from 'react';
import { Activity, Attachment, HeroCardContent, OAuthCardContent, ThumbnailCardContent } from '../types';

interface MessageBubbleProps {
  activity: Activity;
  isOwn: boolean;
  onSuggestedActionClick?: (value: string) => void;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ activity, isOwn, onSuggestedActionClick }) => {
  
  // Helper to parse card content safely
  const getCardContent = <T,>(attachment: Attachment): T | null => {
    if (!attachment.content) return null;
    return attachment.content as T;
  };

  const renderAttachment = (attachment: Attachment, index: number) => {
    // 1. Images
    if (attachment.contentType && attachment.contentType.startsWith('image/')) {
       return (
         <img 
           key={index} 
           src={attachment.contentUrl} 
           alt={attachment.name || 'Attachment'} 
           className="max-w-xs rounded-lg mt-2 border border-gray-700" 
         />
       );
    }

    // 2. Hero Cards / Thumbnail Cards
    if (attachment.contentType === 'application/vnd.microsoft.card.hero' || 
        attachment.contentType === 'application/vnd.microsoft.card.thumbnail') {
      const content = getCardContent<HeroCardContent | ThumbnailCardContent>(attachment);
      if (!content) return null;

      return (
        <div key={index} className="bg-gray-800 border border-gray-700 rounded-lg p-3 mt-2 max-w-sm">
           {content.images && content.images.length > 0 && (
             <img src={content.images[0].url} alt={content.images[0].alt} className="w-full h-32 object-cover rounded-md mb-2" />
           )}
           {content.title && <h4 className="font-bold text-white text-sm">{content.title}</h4>}
           {content.subtitle && <p className="text-gray-400 text-xs">{content.subtitle}</p>}
           {content.text && <p className="text-gray-300 text-sm mt-1">{content.text}</p>}
           
           {content.buttons && (
             <div className="flex flex-col gap-2 mt-3">
               {content.buttons.map((btn, btnIdx) => (
                 <button 
                   key={btnIdx}
                   onClick={() => onSuggestedActionClick?.(btn.value)}
                   className="w-full text-center py-2 px-3 bg-gray-700 hover:bg-gray-600 text-blue-400 text-sm font-medium rounded transition"
                 >
                   {btn.title}
                 </button>
               ))}
             </div>
           )}
        </div>
      );
    }

    // 3. OAuth Cards (Sign In)
    if (attachment.contentType === 'application/vnd.microsoft.card.oauth') {
        const content = getCardContent<OAuthCardContent>(attachment);
        return (
            <div key={index} className="bg-gray-800 border border-blue-900/50 p-4 rounded-xl mt-2 max-w-sm shadow-lg">
                <div className="flex items-center gap-3 mb-3">
                    <div className="bg-blue-900/30 p-2 rounded-full">
                        <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                    </div>
                    <div>
                         <h4 className="font-bold text-white text-sm">Authentication Required</h4>
                         <p className="text-gray-400 text-xs">{content?.text || "Please sign in to continue."}</p>
                    </div>
                </div>
                {content?.buttons && content.buttons.map((btn, btnIdx) => (
                    <a
                        key={btnIdx}
                        href={btn.value} // OAuth card buttons usually contain the sign-in link
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block w-full text-center py-2 px-4 bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold rounded-lg transition"
                    >
                        {btn.title}
                    </a>
                ))}
            </div>
        )
    }

    // 4. File Downloads (Generic)
    if (attachment.contentUrl) {
         return (
             <a key={index} href={attachment.contentUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 p-3 bg-gray-800 rounded-lg mt-2 hover:bg-gray-700 transition group">
                 <div className="p-2 bg-gray-700 group-hover:bg-gray-600 rounded">
                     <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                 </div>
                 <div className="flex flex-col overflow-hidden">
                     <span className="text-sm font-medium text-gray-200 truncate">{attachment.name || 'Download File'}</span>
                     <span className="text-xs text-gray-500 uppercase">{attachment.contentType.split('/').pop()}</span>
                 </div>
             </a>
         );
    }

    return null;
  };

  // Specific Error Handling for "Integrated Auth"
  const isAuthError = !isOwn && activity.text && (
    activity.text.includes("Integrated authentication not supported") || 
    activity.text.includes("integrated authentication not supported")
  );

  return (
    <div className={`flex flex-col ${isOwn ? 'items-end' : 'items-start'} mb-4 animate-fade-in`}>
       <div className={`flex max-w-[85%] ${isOwn ? 'flex-row-reverse' : 'flex-row'} items-end gap-2`}>
           
           {/* Avatar */}
           <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold ${
               isOwn ? 'bg-indigo-600 text-white' : 'bg-green-600 text-white'
           }`}>
               {isOwn ? 'You' : 'Bot'}
           </div>

           {/* Content */}
           <div className={`flex flex-col ${isOwn ? 'items-end' : 'items-start'}`}>
                
                {/* Text Bubble */}
                {activity.text && !isAuthError && (
                    <div className={`px-4 py-2.5 rounded-2xl shadow-sm text-sm whitespace-pre-wrap leading-relaxed ${
                        isOwn 
                        ? 'bg-blue-600 text-white rounded-br-none' 
                        : 'bg-gray-800 text-gray-100 rounded-bl-none border border-gray-700'
                    }`}>
                        {activity.text}
                    </div>
                )}

                {/* Error Bubble (Special Case) */}
                {isAuthError && (
                    <div className="bg-orange-900/40 border border-orange-500/50 p-4 rounded-xl max-w-md">
                        <div className="flex items-start gap-3">
                            <svg className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                            <div>
                                <h3 className="text-orange-200 font-bold text-sm mb-1">Authentication Config Error</h3>
                                <p className="text-orange-100/80 text-xs mb-2">
                                    The agent is trying to use "Integrated Authentication" (SSO), which only works in Microsoft Teams.
                                </p>
                                <div className="bg-black/30 p-2 rounded text-xs text-orange-200/90 font-mono">
                                    Go to Copilot Studio &gt; Settings &gt; Security &gt; Authentication &gt; Choose "Manual (for any channel)" or "No Authentication".
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* Attachments */}
                {activity.attachments && activity.attachments.map((att, idx) => renderAttachment(att, idx))}

                {/* Timestamp */}
                <span className="text-[10px] text-gray-500 mt-1 px-1">
                    {new Date(activity.timestamp || Date.now()).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                </span>
           </div>
       </div>

       {/* Suggested Actions (Chips) */}
       {activity.suggestedActions && activity.suggestedActions.actions && (
           <div className="flex flex-wrap gap-2 mt-2 ml-10">
               {activity.suggestedActions.actions.map((action, idx) => (
                   <button
                       key={idx}
                       onClick={() => onSuggestedActionClick?.(action.value)}
                       className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 border border-blue-500/30 text-blue-400 text-xs font-medium rounded-full transition-colors"
                   >
                       {action.title}
                   </button>
               ))}
           </div>
       )}
    </div>
  );
};

export default MessageBubble;